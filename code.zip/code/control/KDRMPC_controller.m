classdef KDRMPC_controller

    properties
        N
        model
        weights

        upperbound
        lowerbound
        terminal_pos_tol
        terminal_psi_tol
        delta_u_max

        Xc
        Uc
        W
        Z
        Xc_robust
        Uc_robust

        K_tube
        F_tube
        tube_steps
    end

    methods
        function obj = KDRMPC_controller(N,model,weights,upperbound,lowerbound, ...
                terminal_pos_tol,terminal_psi_tol,delta_u_max, ...
                uvr_min,uvr_max,tube_steps)

            obj.N = N;
            obj.model = model;
            obj.weights = weights;
            obj.upperbound = upperbound(:);
            obj.lowerbound = lowerbound(:);
            obj.terminal_pos_tol = terminal_pos_tol;
            obj.terminal_psi_tol = terminal_psi_tol;
            obj.delta_u_max = delta_u_max(:);
            obj.tube_steps = tube_steps;

            obj.K_tube = model.K_tube;
            obj.F_tube = model.F_tube;

            obj.Xc = Polyhedron('lb',uvr_min(:),'ub',uvr_max(:));
            obj.Uc = Polyhedron('lb',obj.lowerbound,'ub',obj.upperbound);
            obj.W = Polyhedron( ...
                'lb',-model.W_uvr_halfwidth(:), ...
                'ub', model.W_uvr_halfwidth(:));

            % Tube：Z = W (+) FW (+) ... (+) F^(L-1)W
            obj.Z = obj.W;
            F_power = eye(3);
            for k = 1:obj.tube_steps-1-1
                F_power = obj.F_tube*F_power;
                obj.Z = obj.Z + F_power*obj.W;
            end

            obj.Xc_robust = obj.Xc - obj.Z;
            obj.Uc_robust = obj.Uc - obj.K_tube*obj.Z;

        end

        function [X,u_mpc,uvr_hat0] = nominal_prediction( ...
                obj,decision,X0,dt,zlift_actual)

            uvr_hat0 = decision(1:3);
            u_mpc = reshape(decision(4:end),2,obj.N);

            X00 = X0([1,2,4,5,6,8]);
            uvr_actual = X00(4:6);
            X00(4:6) = uvr_hat0;

            z0_nominal = obj.model.shift_lift_center( ...
                zlift_actual,uvr_actual,uvr_hat0);

            X = obj.model.predict_sequence(X00,u_mpc,dt,z0_nominal);
        end

        function cost = dlmpc_cost_avoidance(obj,decision,X0,Ref,X_neighbors,dt,dr,wind, ...
                previous_u,zlift_actual)

            Hp = obj.N;

            Q  = obj.weights{1};
            H  = obj.weights{2};
            R  = obj.weights{3};
            F  = obj.weights{4};
            Qf = obj.weights{5};

            [X,u_mpc] = obj.nominal_prediction(decision,X0,dt,zlift_actual);

            psi_r = Ref.Psi(:);
            X_r = Ref.Xr(:);
            Y_r = Ref.Yr(:);
            previous_u = previous_u(:);

            cost = 0;

            d1r = [20;0];
            d2r = [0;-20];
            d3r = [0;20];
            d0r = [0;0];

            for k = 1:Hp-1
                psi_err = atan2(sin(psi_r(k)-X(3,k)), cos(psi_r(k)-X(3,k)));

                e_track = [X_r(k)-X(1,k), Y_r(k)-X(2,k), psi_err];

                if isequal(dr(:),d1r) || isequal(dr(:),d2r) || isequal(dr(:),d3r)
                    cost = cost ...
                        + e_track*Q*e_track' ...
                        + (X(1:2,k)-dr-X_neighbors{1}(1:2,k))'*F*(X(1:2,k)-dr-X_neighbors{1}(1:2,k)) ...
                        + (X(1:2,k)-dr-X_neighbors{2}(1:2,k))'*H*(X(1:2,k)-dr-X_neighbors{2}(1:2,k)) ...
                        + (X(1:2,k)-dr-X_neighbors{3}(1:2,k))'*H*(X(1:2,k)-dr-X_neighbors{3}(1:2,k))...
                        + 100/(1+(norm(X(1:2,k) - X_neighbors{1}(1:2,k) - 6))^2)...
                        + 100/(1+(norm(X(1:2,k) - X_neighbors{2}(1:2,k) - 6))^2);
                elseif isequal(dr(:),d0r)
                    cost = cost + Q(3,3)*psi_err^2;
                end
            end

            for k = 1:Hp
                uk = u_mpc(:,k);
                cost = cost + uk'*R*uk + duk'*Q4*duk;
            end

            if ~isequal(dr(:),d0r)
                psi_terminal_err = atan2(sin(psi_r(Hp)-X(3,Hp)), cos(psi_r(Hp)-X(3,Hp)));

                e_Hp = [X_r(Hp)-X(1,Hp), Y_r(Hp)-X(2,Hp), psi_terminal_err];

                cost = cost + e_Hp*Qf*e_Hp';
            end

        end

        function [c,ceq] = tube_constraints( ...
                obj,decision,X0,Ref,dt,dr,previous_u,zlift_actual)

            [X,u_mpc,uvr_hat0] = obj.nominal_prediction( ...
                decision,X0,dt,zlift_actual);

            c = [];
            ceq = [];

            uvr_actual = X0([5,6,8]);
            e_uvr0 = uvr_actual-uvr_hat0;

            c = [c;obj.Z.A*e_uvr0-obj.Z.b];

            c = [c;obj.Xc_robust.A*uvr_hat0-obj.Xc_robust.b];
            for k = 1:obj.N
                c = [c; ...
                    obj.Xc_robust.A*X(4:6,k)-obj.Xc_robust.b]; 
            end

            for k = 1:obj.N
                c = [c; ...
                    obj.Uc_robust.A*u_mpc(:,k)-obj.Uc_robust.b]; 
            end

            for k = 1:obj.N
                if k == 1
                    du = u_mpc(:,1)-previous_u(:);
                else
                    du = u_mpc(:,k)-u_mpc(:,k-1);
                end

                c = [c;
                     du-obj.delta_u_max;
                    -du-obj.delta_u_max];
            end

            x_N = X(1,end);
            y_N = X(2,end);
            psi_N = X(3,end);

            e_psi_N = atan2( ...
                sin(Ref.Psi(end)-psi_N), ...
                cos(Ref.Psi(end)-psi_N));

            if norm(dr(:)) < 1e-10
                c = [c;e_psi_N^2-obj.terminal_psi_tol^2];
            else
                e_pos_N = [Ref.Xr(end)-x_N;Ref.Yr(end)-y_N];
                c = [c;
                     e_pos_N'*e_pos_N-obj.terminal_pos_tol^2;
                     e_psi_N^2-obj.terminal_psi_tol^2];
            end
        end

        function [u_actual,X,u_opt,diagnostics] = ...
                calc_control_avoidance( ...
                obj,Ref,X_neighbors,X0,u0,dt,dr,wind,previous_u)

            Hp = obj.N;

            if isempty(u0) || numel(u0) ~= 2*Hp
                u0 = repmat(previous_u(:),Hp,1);
            else
                u0 = u0(:);
            end

            uvr_actual = X0([5,6,8]);
            decision0 = [uvr_actual;u0];

            lb = [-inf(3,1);repmat(obj.lowerbound,Hp,1)];
            ub = [ inf(3,1);repmat(obj.upperbound,Hp,1)];

            X00 = X0([1,2,4,5,6,8]);
            zlift_actual = obj.model.lift_state(X00);

            options = optimoptions(@fmincon, ...
                'Algorithm','sqp', ...
                'MaxIterations',200, ...
                'MaxFunctionEvaluations',10000, ...
                'ConstraintTolerance',1e-6, ...
                'OptimalityTolerance',1e-5, ...
                'StepTolerance',1e-8, ...
                'Display','none');

            [decision_opt,fval,exitflag] = fmincon( ...
                @(decision) obj.dlmpc_cost_avoidance( ...
                    decision,X0,Ref,X_neighbors,dt,dr,wind, ...
                    previous_u,zlift_actual), ...
                decision0,[],[],[],[],lb,ub, ...
                @(decision) obj.tube_constraints( ...
                    decision,X0,Ref,dt,dr,previous_u,zlift_actual), ...
                options);

            [X_pred,u_opt,uvr_hat0] = obj.nominal_prediction( ...
                decision_opt,X0,dt,zlift_actual);

            e_uvr0 = uvr_actual-uvr_hat0;
            u_feedback = obj.K_tube*e_uvr0;
            u_actual = u_opt(:,1)+u_feedback;

            X = X_pred;
            X(1:2,:) = X(1:2,:)-dr(:);
        end
    end
end
