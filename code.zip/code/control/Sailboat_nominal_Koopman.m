classdef Sailboat_nominal_Koopman < handle

    properties (SetAccess = private)
        koopan_lift

        A_lift
        B_lift
        C_lift
        d_lift

        A_uvr
        B_uvr
        K_tube
        F_tube
        W_uvr_halfwidth
        Ts

        nx_c
        nu_c
        Q
        R
    end

    methods (Access = public)

        function obj = Sailboat_nominal_Koopman(nx_c, nu_c, Q, R, model_dir)

            if nargin < 5 || isempty(model_dir)
                model_dir = fullfile('Data','matlab_model');
            end

            obj.koopan_lift = importONNXFunction( ...
                fullfile(model_dir,'koopman_encode.onnx'), ...
                'koopmanencode');

            data = load(fullfile(model_dir,'koopman_tube_model.mat'));

            obj.A_lift = data.A_lift;      
            obj.B_lift = data.B_lift;      
            obj.C_lift = data.C_lift;     
            obj.d_lift = data.d_lift(:);

            obj.A_uvr = data.A_uvr;
            obj.B_uvr = data.B_uvr;
            obj.K_tube = data.K_tube;
            obj.F_tube = data.F_tube;
            obj.W_uvr_halfwidth = data.W_uvr_halfwidth(:);
            obj.Ts = data.Ts;

            obj.nx_c = nx_c;
            obj.nu_c = nu_c;
            obj.Q = Q;
            obj.R = R;
        end

        %  x = [x;y;psi;u;v;r]
        function z0 = lift_state(obj, x)

            x = x(:);
            x_uvr = x(4:6).';

            z0 = koopmanencode(x_uvr, obj.koopan_lift);

            if isa(z0,'dlarray')
                z0 = extractdata(z0);
            end

            z0 = double(z0(:));
        end

        function X_pred = predict_sequence(obj, x0, U_seq, dt, z0)

            x0 = x0(:);

            if nargin < 5 || isempty(z0)
                z = obj.lift_state(x0);
            else
                z = z0(:);
            end

            N = size(U_seq,2);
            X_pred = zeros(6,N);
            x_now = x0;

            for k = 1:N

                uk = U_seq(:,k);
                z = obj.A_lift*z + obj.B_lift*uk + obj.d_lift;

                uvr_next = obj.C_lift*z;
                u_next = uvr_next(1);
                v_next = uvr_next(2);
                r_next = uvr_next(3);

                x_next = x_now(1) + (u_next*cos(x_now(3))-v_next*sin(x_now(3)))*dt;
                y_next = x_now(2) + (u_next*sin(x_now(3))+v_next*cos(x_now(3)))*dt;
                psi_next = x_now(3) + r_next*dt;

                x_now = [x_next;y_next;psi_next;u_next;v_next;r_next];
                X_pred(:,k) = x_now;
            end
        end

        function x_next = propagate(obj, x, u, dt)
            X_pred = obj.predict_sequence(x,u(:),dt,[]);
            x_next = X_pred(:,1);
        end
    end
end
