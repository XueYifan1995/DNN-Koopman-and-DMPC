# DNN-Koopman Training and Export

This folder contains the training and export codes for the DNN-Koopman model used in the sailboat MPC controller.

## Files

```text
Train_DNN_Koopman_Model.py
Export_ONNX.py
```

## 1. Train the Model

The training state is:

```text
[u, v, r]
```

The control input is:

```text
[delta_r, delta_s]
```

## 2. Export the Model

Run:

```bash
python Export_ONNX.py 
```

The export code only generates:

```text
koopman_encode.onnx
A.mat
B.mat
C.mat
```

## 3. MATLAB Usage

```matlab
z0 = koopmanencode([u, v, r], params);

z1 = A * z0 + B * [delta_r; delta_s];

uvr1 = C * z1;
```

where

```text
uvr1 = [u_next; v_next; r_next]
```
