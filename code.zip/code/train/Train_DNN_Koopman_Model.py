# ============================================================
# DNN-Koopman training code for UES 3-DOF model
# ------------------------------------------------------------
#   Train only the nominal DNN-Koopman model used in the paper:
#       z(k+1) = A_lift z(k) + B_lift u(k)
#       x(k)   = C_lift z(k),  x=[u_body, v_body, r]^T
#
# Dataset:
#   Default input is sail_episode_dataset.mat.
#   Preferred MAT structure:
#       all.u_body, all.v_body, all.r,
#       all.delta_r, all.delta_s,
#       all.episode_id
#
#   state        : [u, v, r]
#   input        : [delta_r, delta_s]
#   encoder      : [3, 128, 128, 128, 20], ReLU hidden layers
#   lifted state : [x, phi_theta(x)], dimension 3+20=23
#   optimizer    : Adam, beta1=0.9, beta2=0.999, lr=1e-3
#   batch size   : 64
#   loss         : L = 1.0*Lpre + 1.0*Llinear + 0.3*Lrec
#                      + 1e-9*||theta_e||^2
#   normalization: min-max normalization for velocity state x
# ============================================================

import argparse
import copy
import json
import os
import random
from collections import OrderedDict
from pathlib import Path
from typing import Dict, Tuple

import numpy as np
import scipy.io as scio
import torch
import torch.nn as nn


# ============================================================
# 1. Basic utilities
# ============================================================

def set_seed(seed: int) -> None:
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def as_2d_array(value) -> np.ndarray:
    arr = np.asarray(value, dtype=np.float64)
    arr = np.squeeze(arr)
    if arr.ndim == 1:
        arr = arr.reshape(1, -1)
    return arr


def read_struct_field(struct_obj, name: str) -> np.ndarray:
    if not hasattr(struct_obj, name):
        raise KeyError(f"MAT struct 'all' does not contain field '{name}'.")
    return np.asarray(getattr(struct_obj, name), dtype=np.float64).reshape(-1)


def normalize_state(x: np.ndarray, eps: float = 1e-12) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    x_min = np.min(x, axis=1, keepdims=True)
    x_max = np.max(x, axis=1, keepdims=True)
    scale = x_max - x_min
    scale[scale < eps] = 1.0
    x_norm = (x - x_min) / scale
    return x_norm, x_min.reshape(-1), x_max.reshape(-1)


def ensure_time_by_channel(arr: np.ndarray, expected_channels: int) -> np.ndarray:
    arr = np.asarray(arr, dtype=np.float64)
    arr = np.squeeze(arr)

    if arr.ndim != 2:
        raise ValueError(f"Expected a 2-D array, got shape {arr.shape}.")

    if arr.shape[0] == expected_channels:
        return arr
    if arr.shape[1] == expected_channels:
        return arr.T

    raise ValueError(
        f"Cannot interpret shape {arr.shape} as [{expected_channels}, samples]."
    )


# ============================================================
# 2. Dataset loader
# ============================================================

def load_sail_episode_dataset(mat_path: Path):

    mat = scio.loadmat(mat_path, squeeze_me=True, struct_as_record=False)

    if "all" in mat:
        data = mat["all"]
        x_raw = np.vstack([
            read_struct_field(data, "u_body"),
            read_struct_field(data, "v_body"),
            read_struct_field(data, "r"),
        ])
        u_raw = np.vstack([
            read_struct_field(data, "delta_r"),
            read_struct_field(data, "delta_s"),
        ])
        if hasattr(data, "episode_id"):
            episode_id = np.asarray(data.episode_id).astype(int).reshape(-1)
        else:
            episode_id = np.ones(x_raw.shape[1], dtype=int)

        if x_raw.shape[1] != u_raw.shape[1] or x_raw.shape[1] != episode_id.size:
            raise ValueError("Inconsistent sample lengths in 'all' dataset.")
        return x_raw, u_raw, episode_id

    state_key = None
    for key in ["states", "state", "x", "X"]:
        if key in mat:
            state_key = key
            break
    input_key = None
    for key in ["inputs", "input", "u", "U"]:
        if key in mat:
            input_key = key
            break

    if state_key is None or input_key is None:
        available = [k for k in mat.keys() if not k.startswith("__")]
        raise KeyError(
            "Cannot find dataset arrays. Expected 'all' struct, or states/x and inputs/u. "
            f"Available keys: {available}"
        )

    states = np.asarray(mat[state_key], dtype=np.float64)
    inputs = np.asarray(mat[input_key], dtype=np.float64)

    if states.ndim == 3:
        # [episodes, time, channels]
        if states.shape[-1] == 3 and inputs.shape[-1] == 2:
            E, T, _ = states.shape
            x_raw = states.reshape(E * T, 3).T
            u_raw = inputs.reshape(E * T, 2).T
            episode_id = np.repeat(np.arange(E), T)
            return x_raw, u_raw, episode_id

        # [channels, time, episodes]
        if states.shape[0] == 3 and inputs.shape[0] == 2:
            C, T, E = states.shape
            x_raw = np.transpose(states, (2, 1, 0)).reshape(E * T, 3).T
            u_raw = np.transpose(inputs, (2, 1, 0)).reshape(E * T, 2).T
            episode_id = np.repeat(np.arange(E), T)
            return x_raw, u_raw, episode_id

        raise ValueError(f"Unsupported 3-D state/input shapes: {states.shape}, {inputs.shape}")

    x_raw = ensure_time_by_channel(states, 3)
    u_raw = ensure_time_by_channel(inputs, 2)

    if x_raw.shape[1] != u_raw.shape[1]:
        raise ValueError("State and input sample numbers are inconsistent.")

    if "episode_id" in mat:
        episode_id = np.asarray(mat["episode_id"]).astype(int).reshape(-1)
    elif "ep_id" in mat:
        episode_id = np.asarray(mat["ep_id"]).astype(int).reshape(-1)
    else:
        episode_id = np.ones(x_raw.shape[1], dtype=int)

    if episode_id.size != x_raw.shape[1]:
        raise ValueError("episode_id length does not match sample number.")

    return x_raw, u_raw, episode_id


# ============================================================
# 3. Window collection
# ============================================================

def split_episodes(episode_ids: np.ndarray, seed: int):
    unique_ids = np.unique(episode_ids)
    rng = np.random.default_rng(seed)
    rng.shuffle(unique_ids)

    n_total = len(unique_ids)
    n_train = int(0.70 * n_total)
    n_test = int(0.15 * n_total)

    train_ids = unique_ids[:n_train]
    test_ids = unique_ids[n_train:n_train + n_test]
    valid_ids = unique_ids[n_train + n_test:]

    if len(valid_ids) == 0:
        valid_ids = test_ids.copy()
    if len(test_ids) == 0:
        test_ids = valid_ids.copy()

    return train_ids, test_ids, valid_ids


def collect_windows(
    x_all: np.ndarray,
    u_all: np.ndarray,
    episode_ids: np.ndarray,
    selected_ids: np.ndarray,
    steps: int,
    stride: int,
    n_input: int = 2,
    n_state: int = 3,
) -> np.ndarray:
    windows = []

    for ep in selected_ids:
        idx = np.where(episode_ids == ep)[0]
        if idx.size < steps + 1:
            continue

        idx = np.sort(idx)

        for start in range(0, idx.size - steps, stride):
            sample_idx = idx[start:start + steps + 1]
            block = np.zeros((steps + 1, n_input + n_state), dtype=np.float64)
            block[:, :n_input] = u_all[:, sample_idx].T
            block[:, n_input:] = x_all[:, sample_idx].T
            windows.append(block)

    if len(windows) == 0:
        raise RuntimeError("No training windows were collected. Check episode length, steps, and stride.")

    return np.stack(windows, axis=1)


# ============================================================
# 4. Network
# ============================================================

class DNNKoopman(nn.Module):
    def __init__(self, n_state=3, n_input=2, encode_dim=20, layer_depth=3, layer_width=128):
        super().__init__()
        self.n_state = n_state
        self.n_input = n_input
        self.encode_dim = encode_dim
        self.n_koopman = n_state + encode_dim

        widths = [n_state] + [layer_width] * layer_depth + [encode_dim]
        layers = OrderedDict()
        for i in range(len(widths) - 1):
            layers[f"linear_{i}"] = nn.Linear(widths[i], widths[i + 1])
            if i != len(widths) - 2:
                layers[f"relu_{i}"] = nn.ReLU()
        self.encode_net = nn.Sequential(layers)

        self.lA = nn.Linear(self.n_koopman, self.n_koopman, bias=False)
        self.lB = nn.Linear(n_input, self.n_koopman, bias=False)
        self.lC = nn.Linear(self.n_koopman, n_state, bias=False)

        self.reset_parameters()

    def reset_parameters(self):
        with torch.no_grad():
            # Stable initial Koopman matrix.
            self.lA.weight.copy_(
                0.9 * torch.eye(self.n_koopman, dtype=torch.float64)
                + 0.01 * torch.randn(self.n_koopman, self.n_koopman, dtype=torch.float64)
            )
            nn.init.xavier_uniform_(self.lB.weight)

            self.lC.weight.zero_()
            self.lC.weight[:, :self.n_state] = torch.eye(self.n_state, dtype=torch.float64)

    def encode(self, x):
        return torch.cat([x, self.encode_net(x)], dim=-1)

    def forward(self, z, control):
        return self.lA(z) + self.lB(control)

    def decode(self, z):
        return self.lC(z)


# ============================================================
# 5. Loss functions
# ============================================================

def loss_parts(data_np: np.ndarray, model: DNNKoopman, mse, device, gamma: float):
    data = torch.as_tensor(data_np, dtype=torch.float64, device=device)

    x_seq = data[:, :, model.n_input:]
    u_seq = data[:, :, :model.n_input]
    horizon = data.shape[0] - 1

    z_pred = model.encode(x_seq[0])

    loss_pre = torch.zeros((), dtype=torch.float64, device=device)
    loss_linear = torch.zeros((), dtype=torch.float64, device=device)
    loss_rec = torch.zeros((), dtype=torch.float64, device=device)

    pred_weight_sum = 0.0
    rec_weight_sum = 0.0
    beta = 1.0

    for j in range(horizon + 1):
        # Reconstruction loss: x_j -> z_j -> x_j.
        z_true_now = model.encode(x_seq[j])
        x_rec = model.decode(z_true_now)
        loss_rec = loss_rec + beta * mse(x_rec, x_seq[j])
        rec_weight_sum += beta

        if j < horizon:
            z_pred = model(z_pred, u_seq[j])
            z_true_next = model.encode(x_seq[j + 1])
            x_pred_next = model.decode(z_pred)

            loss_linear = loss_linear + beta * mse(z_pred, z_true_next)
            loss_pre = loss_pre + beta * mse(x_pred_next, x_seq[j + 1])
            pred_weight_sum += beta

        beta *= gamma

    loss_pre = loss_pre / pred_weight_sum
    loss_linear = loss_linear / pred_weight_sum
    loss_rec = loss_rec / rec_weight_sum

    encoder_reg = torch.zeros((), dtype=torch.float64, device=device)
    for parameter in model.encode_net.parameters():
        encoder_reg = encoder_reg + torch.sum(parameter ** 2)

    return {
        "pre": loss_pre,
        "linear": loss_linear,
        "rec": loss_rec,
        "encoder_reg": encoder_reg,
    }


def total_loss(parts: Dict[str, torch.Tensor], alpha_pre, alpha_linear, alpha_rec, alpha_reg):
    return (
        alpha_pre * parts["pre"]
        + alpha_linear * parts["linear"]
        + alpha_rec * parts["rec"]
        + alpha_reg * parts["encoder_reg"]
    )


@torch.no_grad()
def evaluate_loss(data_np, model, mse, device, gamma, batch_size, alpha_pre, alpha_linear, alpha_rec, alpha_reg):
    model.eval()
    n_windows = data_np.shape[1]
    totals = {"total": 0.0, "pre": 0.0, "linear": 0.0, "rec": 0.0, "encoder_reg": 0.0}

    for start in range(0, n_windows, batch_size):
        end = min(start + batch_size, n_windows)
        batch = data_np[:, start:end, :]
        this_size = end - start
        parts = loss_parts(batch, model, mse, device, gamma)
        loss = total_loss(parts, alpha_pre, alpha_linear, alpha_rec, alpha_reg)

        totals["total"] += float(loss.item()) * this_size
        for key in ["pre", "linear", "rec", "encoder_reg"]:
            totals[key] += float(parts[key].item()) * this_size

    for key in totals:
        totals[key] /= n_windows

    A = model.lA.weight.detach().cpu().numpy()
    totals["rho_A"] = float(np.max(np.abs(np.linalg.eigvals(A))))
    return totals


# ============================================================
# 6. Main training
# ============================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=str, default="sail_episode_dataset.mat")
    parser.add_argument("--output-dir", type=str, default="Data/dnn_koopman_model_only_paper_aligned")
    parser.add_argument("--seed", type=int, default=98)
    parser.add_argument("--train-steps", type=int, default=20000)
    parser.add_argument("--window-steps", type=int, default=30)
    parser.add_argument("--window-stride", type=int, default=30)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--eval-batch-size", type=int, default=256)
    parser.add_argument("--eval-interval", type=int, default=500)
    parser.add_argument("--encode-dim", type=int, default=20)
    parser.add_argument("--layer-depth", type=int, default=3)
    parser.add_argument("--layer-width", type=int, default=128)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--gamma", type=float, default=1.0)
    parser.add_argument("--alpha-pre", type=float, default=1.0)
    parser.add_argument("--alpha-linear", type=float, default=1.0)
    parser.add_argument("--alpha-rec", type=float, default=0.3)
    parser.add_argument("--alpha-reg", type=float, default=1e-9)
    args = parser.parse_args()

    os.environ["KMP_DUPLICATE_LIB_OK"] = "True"
    torch.set_default_dtype(torch.float64)

    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    dataset_path = Path(args.dataset)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    x_raw, u_raw, episode_id = load_sail_episode_dataset(dataset_path)

    if not np.isfinite(x_raw).all() or not np.isfinite(u_raw).all():
        raise ValueError("Dataset contains NaN or Inf.")

    x_all, state_min, state_max = normalize_state(x_raw)

    train_ids, test_ids, valid_ids = split_episodes(episode_id, args.seed)

    train_data = collect_windows(x_all, u_raw, episode_id, train_ids, args.window_steps, args.window_stride)
    valid_data = collect_windows(x_all, u_raw, episode_id, valid_ids, args.window_steps, args.window_stride)
    test_data = collect_windows(x_all, u_raw, episode_id, test_ids, args.window_steps, args.window_stride)

    model = DNNKoopman(
        n_state=3,
        n_input=2,
        encode_dim=args.encode_dim,
        layer_depth=args.layer_depth,
        layer_width=args.layer_width,
    ).to(device).double()

    mse = nn.MSELoss(reduction="mean")
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, betas=(0.9, 0.999))

    best_valid = float("inf")
    best_state = None
    best_step = -1
    history = []

    for step in range(1, args.train_steps + 1):
        model.train()
        indices = np.random.choice(
            train_data.shape[1],
            size=min(args.batch_size, train_data.shape[1]),
            replace=False,
        )
        batch = train_data[:, indices, :]

        parts = loss_parts(batch, model, mse, device, args.gamma)
        loss = total_loss(parts, args.alpha_pre, args.alpha_linear, args.alpha_rec, args.alpha_reg)

        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()

        if step % args.eval_interval == 0 or step == 1:
            valid_metrics = evaluate_loss(
                valid_data,
                model,
                mse,
                device,
                args.gamma,
                args.eval_batch_size,
                args.alpha_pre,
                args.alpha_linear,
                args.alpha_rec,
                args.alpha_reg,
            )
            history.append({"step": step, **valid_metrics})

            if valid_metrics["total"] < best_valid:
                best_valid = valid_metrics["total"]
                best_step = step
                best_state = copy.deepcopy(model.state_dict())

                torch.save(
                    {
                        "model_state_dict": best_state,
                        "config": vars(args),
                        "state_order": ["u", "v", "r"],
                        "input_order": ["delta_r", "delta_s"],
                        "state_min": state_min,
                        "state_max": state_max,
                        "best_step": best_step,
                        "best_valid_total": best_valid,
                    },
                    output_dir / "best_checkpoint.pth",
                )

            print(
                f"Step {step:6d} | Valid {valid_metrics['total']:.6e} | "
                f"Lpre {valid_metrics['pre']:.6e} | "
                f"Llinear {valid_metrics['linear']:.6e} | "
                f"Lrec {valid_metrics['rec']:.6e} | "
                f"rho(A) {valid_metrics['rho_A']:.6f}"
            )

    if best_state is None:
        raise RuntimeError("No valid checkpoint was saved.")

    model.load_state_dict(best_state)
    model.eval()

    test_metrics = evaluate_loss(
        test_data,
        model,
        mse,
        device,
        args.gamma,
        args.eval_batch_size,
        args.alpha_pre,
        args.alpha_linear,
        args.alpha_rec,
        args.alpha_reg,
    )

    A_lift = model.lA.weight.detach().cpu().numpy()
    B_lift = model.lB.weight.detach().cpu().numpy()
    C_lift = model.lC.weight.detach().cpu().numpy()

    scio.savemat(
        output_dir / "koopman_model_only.mat",
        {
            "A_lift": A_lift,
            "B_lift": B_lift,
            "C_lift": C_lift,
            "state_min": state_min.reshape(-1, 1),
            "state_max": state_max.reshape(-1, 1),
            "state_order": np.array(["u", "v", "r"], dtype=object),
            "input_order": np.array(["delta_r", "delta_s"], dtype=object),
            "best_step": np.array([[best_step]], dtype=np.float64),
            "best_valid_total": np.array([[best_valid]], dtype=np.float64),
            "test_total": np.array([[test_metrics["total"]]], dtype=np.float64),
        },
    )

    with open(output_dir / "training_history.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "history": history,
                "best_step": best_step,
                "best_valid_total": best_valid,
                "test_metrics": test_metrics,
                "config": vars(args),
                "state_order": ["u", "v", "r"],
                "input_order": ["delta_r", "delta_s"],
                "state_min": state_min.tolist(),
                "state_max": state_max.tolist(),
            },
            f,
            ensure_ascii=False,
            indent=2,
        )

    torch.save(model, output_dir / "net.pth")

    print("\n===== Training finished =====")
    print("Best step:", best_step)
    print("Best validation total:", best_valid)
    print("Test metrics:", test_metrics)
    print("Saved:")
    print("  ", output_dir / "best_checkpoint.pth")
    print("  ", output_dir / "koopman_model.mat")
    print("  ", output_dir / "net.pth")


if __name__ == "__main__":
    main()
