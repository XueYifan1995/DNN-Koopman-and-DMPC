# ============================================================
# 
# Only generates:
#   1) koopman_encode.onnx
#   2) A.mat
#   3) B.mat
#   4) C.mat
#
# ONNX:
#   input : x = physical [u,v,r], shape [batch,3]
#   output: z = augmented lifted state [z_norm;1], shape [batch,Nkoopman+1]
#
# MATLAB:
#   z0 = koopmanencode([u,v,r], params);
#   z1 = A*z0 + B*[delta_r;delta_s];
#   uvr1 = C*z1;
# ============================================================

import argparse
from collections import OrderedDict
from pathlib import Path

import numpy as np
import scipy.io as scio
import torch
import torch.nn as nn


class DNNKoopman(nn.Module):

    def __init__(self, n_state=3, n_input=2, encode_dim=20,
                 layer_depth=3, layer_width=128):
        super().__init__()

        self.n_state = n_state
        self.n_input = n_input
        self.encode_dim = encode_dim
        self.n_koopman = n_state + encode_dim

        widths = [n_state] + [layer_width] * layer_depth + [encode_dim]

        layers = OrderedDict()
        for i in range(len(widths) - 1):
            layers[f"linear_{i}"] = nn.Linear(widths[i], widths[i + 1])
            if i != len(widths) - 2:
                layers[f"relu_{i}"] = nn.ReLU()

        self.encode_net = nn.Sequential(layers)

        self.lA = nn.Linear(self.n_koopman, self.n_koopman, bias=False)
        self.lB = nn.Linear(n_input, self.n_koopman, bias=False)
        self.lC = nn.Linear(self.n_koopman, n_state, bias=False)

        self.reset_parameters()

    def reset_parameters(self):
        with torch.no_grad():
            self.lA.weight.copy_(
                0.9 * torch.eye(self.n_koopman, dtype=torch.float64)
                + 0.01 * torch.randn(self.n_koopman, self.n_koopman,
                                     dtype=torch.float64)
            )
            nn.init.xavier_uniform_(self.lB.weight)

            self.lC.weight.zero_()
            self.lC.weight[:, :self.n_state] = torch.eye(
                self.n_state, dtype=torch.float64
            )

    def encode(self, x):
        return torch.cat([x, self.encode_net(x)], dim=-1)

    def forward(self, z, control):
        return self.lA(z) + self.lB(control)

    def decode(self, z):
        return self.lC(z)


class KoopmanPhysicalEncoderONNX(nn.Module):

    def __init__(self, model, state_min, state_scale):
        super().__init__()
        self.model = model

        self.register_buffer(
            "state_min",
            torch.as_tensor(state_min.reshape(1, -1), dtype=torch.float64),
        )
        self.register_buffer(
            "state_scale",
            torch.as_tensor(state_scale.reshape(1, -1), dtype=torch.float64),
        )

    def forward(self, x_phys):
        x_norm = (x_phys - self.state_min) / self.state_scale
        z = self.model.encode(x_norm)

        ones = torch.ones(
            z.shape[0], 1,
            dtype=z.dtype,
            device=z.device,
        )
        z_aug = torch.cat([z, ones], dim=-1)
        return z_aug


def safe_torch_load(path, map_location="cpu"):
    try:
        return torch.load(path, map_location=map_location, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=map_location)


def load_model_from_checkpoint(checkpoint_path):
    ckpt = safe_torch_load(checkpoint_path, map_location="cpu")

    if "model_state_dict" not in ckpt:
        raise KeyError(
            "Checkpoint must contain 'model_state_dict'. "
            f"Available keys: {list(ckpt.keys())}"
        )

    if "state_min" not in ckpt or "state_max" not in ckpt:
        raise KeyError(
            "Checkpoint must contain 'state_min' and 'state_max', because "
            "the training code uses min-max normalization."
        )

    config = ckpt.get("config", {})

    model = DNNKoopman(
        n_state=3,
        n_input=2,
        encode_dim=int(config.get("encode_dim", 20)),
        layer_depth=int(config.get("layer_depth", 3)),
        layer_width=int(config.get("layer_width", 128)),
    ).double()

    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()

    state_min = np.asarray(ckpt["state_min"], dtype=np.float64).reshape(3)
    state_max = np.asarray(ckpt["state_max"], dtype=np.float64).reshape(3)
    state_scale = state_max - state_min
    state_scale[state_scale < 1e-12] = 1.0

    return model, state_min, state_scale


def export_onnx_encoder(model, state_min, state_scale,
                        onnx_path, onnx_dtype="double", opset=17):
    wrapper = KoopmanPhysicalEncoderONNX(model, state_min, state_scale)

    if onnx_dtype == "single":
        wrapper = wrapper.float()
        dummy = torch.zeros(1, 3, dtype=torch.float32)
    else:
        wrapper = wrapper.double()
        dummy = torch.zeros(1, 3, dtype=torch.float64)

    wrapper.eval()

    torch.onnx.export(
        wrapper,
        dummy,
        str(onnx_path),
        export_params=True,
        opset_version=opset,
        do_constant_folding=True,
        input_names=["x"],
        output_names=["z"],
        dynamic_axes={
            "x": {0: "batch"},
            "z": {0: "batch"},
        },
    )


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--training-dir",
        type=str,
        default="Data/dnn_koopman_model_only_paper_aligned",
        help="Directory containing best_checkpoint.pth.",
    )

    parser.add_argument(
        "--checkpoint",
        type=str,
        default="",
        help="Optional direct path to best_checkpoint.pth.",
    )

    parser.add_argument(
        "--output-dir",
        type=str,
        default="Data/matlab_model",
        help="Output directory. Only koopman_encode.onnx, A.mat, B.mat, C.mat will be generated.",
    )

    parser.add_argument(
        "--onnx-dtype",
        type=str,
        default="double",
        choices=["double", "single"],
        help="ONNX precision. Use single if MATLAB importONNXFunction has double compatibility issues.",
    )

    parser.add_argument(
        "--opset",
        type=int,
        default=17,
        help="ONNX opset version.",
    )

    args = parser.parse_args()

    training_dir = Path(args.training_dir)

    if args.checkpoint:
        checkpoint_path = Path(args.checkpoint)
    else:
        checkpoint_path = training_dir / "best_checkpoint.pth"

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    model, state_min, state_scale = load_model_from_checkpoint(checkpoint_path)

    A = model.lA.weight.detach().cpu().numpy()
    B = model.lB.weight.detach().cpu().numpy()
    C_norm = model.lC.weight.detach().cpu().numpy()

    n_koopman = A.shape[0]

    # Augment lifted state: z_aug = [z;1]
    A_aug = np.zeros((n_koopman + 1, n_koopman + 1), dtype=np.float64)
    A_aug[:n_koopman, :n_koopman] = A
    A_aug[-1, -1] = 1.0

    B_aug = np.zeros((n_koopman + 1, B.shape[1]), dtype=np.float64)
    B_aug[:n_koopman, :] = B

    # Physical decode:
    # x_phys = diag(scale)*C_norm*z + state_min
    #        = [diag(scale)*C_norm, state_min] * [z;1]
    C_aug = np.zeros((3, n_koopman + 1), dtype=np.float64)
    C_aug[:, :n_koopman] = np.diag(state_scale) @ C_norm
    C_aug[:, -1] = state_min

    # Save only A.mat, B.mat, C.mat
    scio.savemat(output_dir / "A.mat", {"A": A_aug})
    scio.savemat(output_dir / "B.mat", {"B": B_aug})
    scio.savemat(output_dir / "C.mat", {"C": C_aug})

    # Save only koopman_encode.onnx
    export_onnx_encoder(
        model=model,
        state_min=state_min,
        state_scale=state_scale,
        onnx_path=output_dir / "koopman_encode.onnx",
        onnx_dtype=args.onnx_dtype,
        opset=args.opset,
    )

if __name__ == "__main__":
    main()
